<?php

return [
    'nama_dokumen' => 'Document Name',
    'nama_pengguna' => 'Nama Pengguna',
    'document_type' => 'Type',
    'expired' => 'Expired At',
    'department' => 'Department',
    'tanggal' => 'Tanggal',
    'bulan' => 'Bulan',
    'tahun' => 'Tahun',
    'file' => 'File',
    'name' => 'Name',
    'code' => 'Code',
    'description' => 'Description',
    'status' => 'Status',
    'created_by' => 'Created By',
    'updated_at' => 'Updated At',
    'updated_by' => 'Updated By',
    'deleted_by' => 'Deleted By',
    'action' => 'Action',

];