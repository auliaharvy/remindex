<?php

return [
    'name' => 'Document Type',
];
