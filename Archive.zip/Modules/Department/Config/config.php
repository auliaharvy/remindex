<?php

return [
    'name' => 'Department',
];
