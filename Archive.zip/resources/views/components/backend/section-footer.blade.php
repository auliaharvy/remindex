<div class="row">
    <div class="col">
        <small class="float-end text-muted">
            {{ $slot }}
        </small>
    </div>
</div>